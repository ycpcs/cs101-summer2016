#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "Utils.cpp"
 
 
int main(void)
{
	//declare variables

	// declare a string to hold the name of the file
	// that will be read into your statsArray
	char statsFile[10];							/* file to be read in */
	printf("Enter the file to process: ");
	scanf("%s",statsFile);
	printf("%s",statsFile);
	int arraySize = getFileSize(statsFile);		/* determine size of file */
  
	//dynamically declare statsArray based on size of file
	int *statsArray = (int*)malloc(sizeof(int)*arraySize);
	
	//declare histogram array
	
	
	// initialize arrays with zero values
	/*
		Use the initializeArray function in Utils.cpp. Say you had an array 
		named myArray.  And it's size was stored in a variable of type
		int named mySize.  Then you could call the function
		as follows:
		
		initializeArray(myArray, mySize);
		
		After this line executed, myArray would be filled with zeroes. 
	*/
	
	//load array from file
	/*
		Use the loadArray function in Utils.cpp to load you array with the 
		data from a file.
		Say you had an array named myArray with it's size value stored in
		an int variable named mySize.  Finally, assume you wanted to load the
		data from a file named myFile.txt.  Further, assume you declared a character
		array variable (named myFileNameVariable) to hold the name of the file as follows:
		
		char myFileNameVariable[] = "myFile.txt";
		
		Then you would call the function as follows:
		
		loadArray(myArray, mySize, myFileNameVariable);
		
		After this line executed, myArray would be filled with the data from
		the file myFile.txt
	*/

	
	// sum stats array

	
	//calculate the mean

	
	//calculate standard deviation

	
	//calculate the median

	
	//fill histogram array with proper counts of batting averages

	
	//print histogram

	
	//release memory -
	/*
		Ensure that the following line of code remains just before the
		return statement. It's purpose is to return memory back to the
		computer.  Without this statement, you would have a memory leak.
	*/
	free(statsArray);
	
	return 0;
}

