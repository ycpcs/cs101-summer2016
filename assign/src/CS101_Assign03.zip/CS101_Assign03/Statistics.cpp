#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "Utils.cpp"
 
 
int main(void)
{
	//declare variables

	// declare a string to hold the name of the file
	// that will be read into your statsArray
	char statsFile[10];							/* file to be read in */
	printf("Enter the file to process: ");
	scanf("%s",statsFile);
	printf("%s",statsFile);
	int arraySize = getFileSize(statsFile);		/* determine size of file */
  
	//dynamically declare statsArray based on size of file
	int *statsArray = (int*)malloc(sizeof(int)*arraySize);	
	
	// initialize arrays with zero values
	initializeArray(statsArray,arraySize);
	
	//load array from file
	loadArray(statsArray,arraySize,statsFile);

	//***********************************************
	// TODO: Process statsArray to compute statistics
	//***********************************************
	
	// TODO: sum stats array

	
	// TODO: calculate the mean

	
	// TODO: calculate standard deviation

	
	// TODO: calculate the median
	// Hint: you can sort the array using sortArray(statsArray,arraySize);


	// TODO: declare and initialize histogram array

	
	// TODO: fill histogram array with proper counts of batting averages
	

	// TODO: print histogram

	
	//release memory
	free(statsArray);
	
	return 0;
}

