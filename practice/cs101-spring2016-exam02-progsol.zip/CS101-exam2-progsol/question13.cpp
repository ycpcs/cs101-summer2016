// CS101-101 Exam 2: Question 13
#include <stdio.h>
#include <math.h>

int main(void) {
	// TODO: add your code here
    int date, daysInMonth;

	// get the input from the user
    printf("Enter Sunday date and days in Month: ");
    scanf("%i %i", &date, &daysInMonth);
    
    // output 7 dates for week, starting with Sunday date given
    for (int i = 0; i < 7; i++)
    {
        printf("%i ", date);
        
        // if we hit end of month date, wrap around to start of month (1) 
        if (date == daysInMonth)
        {
            date = 1;
        }
        else
        {
            date++;
        }
    }
    
    return 0;
}
