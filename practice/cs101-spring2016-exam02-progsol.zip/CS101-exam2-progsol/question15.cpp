// CS101-101 Exam 2: Question 15
#include <stdio.h>
#include <math.h>
#define SIZE 20

int main(void) {
	
	// DO NOT MODIFY
	int num_vals = 0;
	int data[SIZE];
	int target = 0;
	
	// Get user input
	printf("Enter number of values: ");
	scanf("%i", &num_vals);
	
	for (int i = 0; i < num_vals; i++) {
		scanf("%i", &data[i]);
	}
	
	printf("Enter target value: ");
	scanf("%i", &target);
	// DO NOT MODIFY

    // TODO: add your code here
	// declare and initialize variables
    int triple;
    int greater = 0, less = 0, equal = 0;
    int greaterTotal = 0, lessTotal = 0, equalTotal = 0;
    
    // loop through the values - but don't run past end of array
    for (int i = 0; i < num_vals - 2; i++)
    {
        // calculate triple once, use it 3 times
        triple = data[i] + data[i + 1] + data[i + 2];
        
        // compare triple to target and update appropriate counters
        if (triple > target)
        {
            greater++;
            greaterTotal += triple;
        }
        else if (triple < target)
        {
            less++;
            lessTotal += triple;
        }
        else
        {
            equal++;
            equalTotal += triple;
        }
    }
    
    // output the results
    printf("There are %i triples greater than %i with total %i\n", greater, target, greaterTotal);
    printf("There are %i triples less than %i with total %i\n", less, target, lessTotal);    
    printf("There are %i triples equal to %i with total %i\n", equal, target, equalTotal);    
    
    // determine which total is greatest
    if ((greaterTotal > equalTotal) && (greaterTotal > lessTotal))
    {
        printf("Greater than has the largest total\n");
    }
    else if ((lessTotal > greaterTotal) && (lessTotal > equalTotal))
    {
        printf("Less than has the largest total\n");
    }
    else if ((equalTotal > greaterTotal) && (equalTotal > lessTotal))
    {
        printf("Equal to has the largest total\n");
    }
    else
    {
        printf("There is no unique greatest total\n");
    }

	return 0;
}
