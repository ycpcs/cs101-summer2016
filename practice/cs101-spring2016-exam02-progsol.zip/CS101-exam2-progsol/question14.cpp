// CS101-101 Exam 2: Question 14

// Write a program that asks the user for the number of exam
// scores they wish to enter. The program should then solicit
// that number of exam scores from the user.  It should find
// the following values:
//    1) the minimum exam score
//    2) the maximum exam score
//    3) the mean of the exam scores AFTER dropping the lowest score.

// The program should output the maximum score, and the mean just calculated.

// All exam scores are integers in the range of 0 - 100.
// The mean should be a floating point number with two decimal digits.

// HINTS: Initialize your minimum value to a value higher than the input range.
//        Initialize your maximum value to a value lower than the input range.
//        To drop the lowest exam score, remove it from the total.
//        Remember to use the correct # of exam scores when finding the mean.

// Example output is shown below:
//
//    Enter number of exams: 4
//    Enter next exam score (0-100): 93
//    Enter next exam score (0-100): 87
//    Enter next exam score (0-100): 63
//    Enter next exam score (0-100): 82
//
//    Min: 63, Max: 93, Mean of 3 highest exams: 87.33

#include <stdio.h>
#include <math.h>

int main(void)
{
    int   numExams;             // accepts # of exams to enter from user           
    int   examScore;            // accepts exam score from user
    int   totalScore = 0;       // accumulate exams scores
    int   min        = 101;     // initialize min to value above input range
    int   max        = -1;      // initialize max to value below input range
    float mean;

    // get # of exams from user
    printf("\nEnter number of exams: ");
    scanf("%i", &numExams);

    for (int i = 0; i < numExams; i++)
    {
        // get exam scores from user
        printf("Enter next exam score (0-100): ");
        scanf("%i", &examScore);
        
        // sum up exam scores
        totalScore += examScore;
        
        // find min score
        if (examScore < min)
        {
            min = examScore;
        }
        
        // find max score
        if (examScore > max)
        {
            max = examScore;
        }
    }

    // remove lowest score from total
    totalScore -= min;
    
    // find mean of remaining scores
    mean = (double) totalScore / (numExams - 1);
    
    // output results
    printf("\nMin: %i, Max: %i, Mean of %i highest exams: %.2f\n", min, max, numExams - 1, mean);
    
    return 0;
}